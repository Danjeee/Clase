package com.example.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DwsU3t1SorianoEsparzaJavierApplicationTests {

	@Test
	void contextLoads() {
	}

}
