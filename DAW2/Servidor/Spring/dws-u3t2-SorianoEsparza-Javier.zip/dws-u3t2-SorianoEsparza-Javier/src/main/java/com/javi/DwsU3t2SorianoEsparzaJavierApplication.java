package com.javi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DwsU3t2SorianoEsparzaJavierApplication {

	public static void main(String[] args) {
		SpringApplication.run(DwsU3t2SorianoEsparzaJavierApplication.class, args);
	}

}
