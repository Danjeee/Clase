package com.iescamp.presencial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamenPresencialApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamenPresencialApplication.class, args);
	}

}
