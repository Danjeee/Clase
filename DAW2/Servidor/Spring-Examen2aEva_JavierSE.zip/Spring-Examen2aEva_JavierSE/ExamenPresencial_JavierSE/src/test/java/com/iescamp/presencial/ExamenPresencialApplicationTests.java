package com.iescamp.presencial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenPresencialApplicationTests {

	@Test
	void contextLoads() {
	}

}
