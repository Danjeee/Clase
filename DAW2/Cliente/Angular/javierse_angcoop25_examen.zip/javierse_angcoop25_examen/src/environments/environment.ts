export const environment = {
  production: false,
  apiUrl: 'http://localhost/pruebaServidor/php/prueba.php',
};
